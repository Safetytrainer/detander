<?php session_start(); ?>
Пользователь <?php print($_SESSION['login']); ?> авторизован
